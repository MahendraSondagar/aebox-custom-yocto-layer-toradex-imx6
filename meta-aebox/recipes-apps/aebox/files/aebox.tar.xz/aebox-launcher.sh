#!/bin/bash

echo "--------------------------------------" >> aebox.log
echo "AEBox Launcher Script 1.4 (2024/09/26)" >> aebox.log

#check if we need to install a software update
VERSION_FILE="aebox-update"
if [ -f $VERSION_FILE ]; then
    echo "Software update file found!" >> aebox.log

    TAR_FILE="aebox_"$(<$VERSION_FILE)"_"$(uname -m)".tar.xz"
    URL="http://downloads.aebox.be/firmware/"$TAR_FILE

    if [[ $(uname -m) == "armv7l" ]]; then
        wget $URL -O $TAR_FILE
    else
        wget --inet4-only $URL -O $TAR_FILE
    fi

    if [ -f $TAR_FILE ]; then
        #backup current version
        mv aebox aebox.bak
        chmod -x aebox.bak

        #extract and cleanup
        tar -xf $TAR_FILE
        rm -f $TAR_FILE
    else
        echo "Failed to download "$TAR_FILE >> aebox.log
    fi

    #cleanup aebox-update file
    rm -f $VERSION_FILE
fi

#end of  script
echo "--------------------------------------" >> aebox.log
