#!/bin/bash

VERSION=1.6

if [ $1 -eq 150 ]; then
  #Disconnect from OpenVPN network (all sessions)  
  ACTIVE_SESSIONS=$(openvpn3 sessions-list | grep -i 'path' | awk '{p=index($0, ":");print $2}')  
  for SESSION in $ACTIVE_SESSIONS; do
    openvpn3 session-manage --disconnect --session-path ${SESSION}
  done
elif [ $1 -eq 151 ]; then
  #Connect to OpenVPN network  
  printf "aebox\nCMyVX&\n" | openvpn3 session-start --config aebox-vpn
elif [ $1 -eq 152 ]; then  
  #Download the aebox OpenVPN configuration file
  wget --inet4-only http://downloads.aebox.be/other/aebox-vpnconfig.ovpn
  #Import config
  openvpn3 config-import --config aebox-vpnconfig.ovpn --name aebox-vpn --persistent
  #Allow compression
  openvpn3 config-manage --config aebox-vpn --allow-compression yes
elif [ $1 -eq 160 ]; then
  #Query all relevant ip addresses  
  VPN_ADDRESS="0.0.0.0"
  PUBLIC_ADDRESS=$(wget -q -O - ifconfig.me)  
  IPS=($(hostname -i))
  LOCAL_ADDRESS=${IPS[0]}  
  for IP in "${IPS[@]}"
  do
    if [[ $IP =~ ^10.8.0.* ]]; then
      VPN_ADDRESS=$IP    
    fi
  done
  #write ip addresses to file  
  printf "$LOCAL_ADDRESS $PUBLIC_ADDRESS $VPN_ADDRESS" > my.ip
elif [ $1 -eq 161 ]; then
  #Query the geolocation based on public ip address
  wget http://ip-api.com/json/ -O geolocation.json
elif [ $1 -eq 162 ]; then
  #A simple internet connection test (pure bash)
  if : >/dev/tcp/8.8.8.8/53; then
    echo "Online"
  else
    echo "Offline"
  fi
else  
  echo "---------------------------------" >> aebox.log
  echo "Networking Tools $VERSION" >> aebox.log
  echo "Unsupported input argument:"$1 >> aebox.log
  echo "---------------------------------" >> aebox.log
fi
