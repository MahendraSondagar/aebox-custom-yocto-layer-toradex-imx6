"""AEBox Utility Module """

import os
from pathlib import Path

def get_ini_path():
    """Return the path of the aebox.ini file."""
    device = os.uname().machine

    # Raspberry Pi
    if device == "aarch64":
        return "/opt/aebox/aebox.ini"

    # iMX6ULL
    if device == "armv7l":
        return "/opt/aebox/aebox.ini"

    # Desktop
    return "../config/aebox.ini"

def get_root_folder():
    """Return the root folder of the AEBox folder structure"""
    return Path(__file__).parent.parent
