"""Downloading a json response from a weather forecast service."""

import os
import sys
import json
import datetime
import urllib.request
from configparser import ConfigParser
import aebox_tools as tools

INI_FILE = tools.get_ini_path()

# Retrieve some settings from INI file
if not os.path.isfile(INI_FILE):
    sys.stdout.write(INI_FILE + " is missing")
    sys.exit()

config = ConfigParser()
config.read(INI_FILE)

lat = config.getfloat('location', 'latitude') if config.has_option('location', 'latitude') else 0.0
lon = config.getfloat('location', 'longitude') if config.has_option('location', 'longitude') else 0.0
kWp = config.getfloat('solar', 'kWp') if config.has_option('solar', 'kWp') else 0.0
declination = config.getint('solar', 'declination') if config.has_option('solar', 'declination') else 0
azimuth = config.getfloat('solar', 'azimuth') if config.has_option('solar', 'azimuth') else 0.0

# We can't request forecast if some key values are missing
if (lat == 0) or (lon == 0) or (kWp == 0):
    sys.stdout.write("Can't generate url when key values are missing")
    sys.exit()

url = f"https://api.forecast.solar/estimate/watthours/{lat:.5f}/{lon:.5f}/{declination}/{azimuth:.1f}/{kWp:.1f}"

webURL = urllib.request.urlopen(url)
data = webURL.read()
JSON_object = json.loads(data.decode('utf-8'))

# Validate response
code = JSON_object['message']['code'] if 'code' in JSON_object['message'] else -1

if code == 0:
    filename = f"{datetime.datetime.now().strftime('%Y%m%d')}-solar.json"
    OUT_FILE = os.path.join(tools.get_root_folder(), "forecasts", filename)

    # Save to file
    with open(OUT_FILE, 'w') as f:
        json.dump(JSON_object, f, ensure_ascii=False)    

    # Clean up old files 
    i = 5
    n = 0
    while i < 30:
        t = datetime.datetime.today() - datetime.timedelta(days=i)
        filename = f"{t.strftime('%Y%m%d')}-solar.json"
        p = os.path.join(tools.get_root_folder(), "forecasts", filename)
        if os.path.exists(p):
            os.remove(p)
            n += 1
        i += 1

    # Return some information for the log file
    sys.stdout.write(f"Saved {OUT_FILE} and deleted {n} obsolete files.")
