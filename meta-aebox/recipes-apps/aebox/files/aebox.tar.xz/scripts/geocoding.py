"""Retrieve GPS coordinates based on address from Google geocoding service."""

import os
import sys
import json
import urllib.parse
import urllib.request
from configparser import ConfigParser
import aebox_tools as tools

API_KEY = "AIzaSyALYviLIpJghnDlCi6sSolGJUCAg8CwG-U"
INI_FILE = tools.get_ini_path()

# Retrieve some settings from INI file
if not os.path.isfile(INI_FILE):
    sys.stdout.write(INI_FILE + " is missing")
    sys.exit()

config = ConfigParser()
config.read(INI_FILE)

street = config.get('location', 'street') if config.has_option('location', 'street') else ""
city = config.get('location', 'city') if config.has_option('location', 'city') else ""

# Remove quotes if any
street = street.strip('\"')
city = city.strip('\"')

# We can't request geocoding if some key values are missing
if (street == "") or (city == "") :
    sys.stdout.write("Can't generate url when key values are missing")
    sys.exit()

url = f"https://maps.googleapis.com/maps/api/geocode/json?address={urllib.parse.quote(street)},{urllib.parse.quote(city)}&key={API_KEY}"

webURL = urllib.request.urlopen(url)
data = webURL.read()
JSON_object = json.loads(data.decode('utf-8'))

# Parse the JSON data
if JSON_object['status'] == "OK":
    lat = JSON_object['results'][0]['geometry']['location']['lat'] if 'lat' in JSON_object['results'][0]['geometry']['location'] else 0.0
    lng = JSON_object['results'][0]['geometry']['location']['lng'] if 'lng' in JSON_object['results'][0]['geometry']['location'] else 0.0

    if not (lat == 0.0 or lng == 0.0):
        # Save coordinates to INI file
        with open(INI_FILE, 'w') as configfile:
            config.set('location', 'latitude', f"{lat:.5f}")
            config.set('location', 'longitude', f"{lng:.5f}")
            config.write(configfile)
            sys.stdout.write("OK")
    else:
        sys.stdout.write("Invalid coordinates")
else:
    sys.stdout.write(JSON_object['status'])
